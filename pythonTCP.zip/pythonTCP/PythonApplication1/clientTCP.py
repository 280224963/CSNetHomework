
from socket import *

#serverName = '192.168.31.133'
serverName = 'localhost'
serverPort = 12000
clientSocket = socket(AF_INET, SOCK_STREAM)
clientSocket.connect((serverName, serverPort))

sentence = input("input a sentence:")
clientSocket.send(sentence.encode())

modifiedSentence = clientSocket.recv(1024)
print("From Server:the length of the sentence is", modifiedSentence.decode())

clientSocket.close()

